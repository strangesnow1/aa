package level;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
 
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
 
public class level1 extends JFrame implements KeyListener{
     //锟斤拷锟斤拷锟斤拷锟街讹拷锟斤拷
    CavansPanel cp = new CavansPanel();//锟斤拷锟斤拷一锟斤拷锟斤拷签锟斤拷锟�
    JPanel ctrl = new JPanel();//锟斤拷锟斤拷一锟斤拷锟斤拷锟�
    ImageIcon im;
    JLabel jl1;
    JLabel jl2;
    JLabel jl3;
   
    long time = 30;
    
   
     //锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
    public level1() {
    	super("level");//鍒涘缓妗嗘灦锛屽懡鍚嶆鏋�
        setUndecorated(true);//璁剧疆妗嗘灦鏃犺竟妗�
        this.setSize(1200,800);//璁剧疆妗嗘灦鐨勫ぇ灏�
	    this.setLocationRelativeTo(null);//浣跨獥鍙ｆ樉绀哄湪灞忓箷涓ぎ
	    
	    String path = "c.jpg";  //璺緞
        ImageIcon background = new ImageIcon(path);//鐢熸垚鍥剧墖  
        JLabel label = new JLabel(background);//鍥剧墖娣诲姞鍒版爣绛鹃噷
        label.setBounds(0, 0,1300, 800);  
	    
        this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));  
        
        JPanel i = (JPanel) this.getContentPane();  
        i.setLayout(null);
        i.setOpaque(false); 
        
        cp.setOpaque(false);
        
        this.addKeyListener(this);//娣诲姞鐩戝惉鍣�
        ctrl.setLayout(new GridLayout(2, 3, 0, 10));//璁剧疆闈㈡澘鐨勫竷灞�
        this.setLayout(new BorderLayout());//璁剧疆妗嗘灦甯冨眬涓鸿竟妗嗗竷灞�锛岃竟妗嗗竷灞�鍒嗕笢鍗楄タ鍖椾腑5涓柟浣嶆潵娣诲姞鎺т欢
        i.add(cp, BorderLayout.CENTER);//娣诲姞闈㈡澘鍒版鏋剁殑涓棿浣嶇疆
        jl1 = new JLabel();//瀹氫箟鏍囩1
        jl2 = new JLabel();//瀹氫箟鏍囩2
        jl3 = new JLabel();//瀹氫箟鏍囩3
      
       
        cp.setLayout(null);
        jl2.setBounds(700, 10, 100, 100);
        jl3.setBounds(720, 10, 100, 100);
        JLabel ll =ll = new JLabel();//瀹氫箟鏍囩3
        ll.setBounds(1100, 30, 70, 50);
        ll.setFont(new Font(null, Font.BOLD,60));
        ll.setText("7");
        cp.add(ll);
        cp.add(jl1);
        cp.add(jl2);
        cp.add(jl3);
       
       
        
 
        
      
      
       
       
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//璁剧疆鍏抽棴鎸夐挳
        this.setVisible(true);//璁剧疆涓哄彲瑙�
        new Thread(cp).start();//鍚姩绾跨▼
    }
     
   
void getTime() {
        
        //声明时分秒变量
       long hour=0;
        long minute = 0;
        long seconds = 0;
       
       
        while (time >= 0) {
            hour = time / 3600;//得到小时
            minute = (time - hour * 3600) / 60;//得到分钟
            seconds = time - hour * 3600 - minute * 60;//得到秒
           
            jl2.setText(minute + ":");//在标签中加入初始的分钟
            jl3.setText(seconds+"");//在标签中加入初始的秒
            
            jl2.setFont(new Font("Aharoni", Font.BOLD, 30));
            jl3.setFont(new Font("Aharoni", Font.BOLD, 30));
           
            //加入时间间隔
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            time--;
            if(time<1){
           	 dispose();
           	 new level2().getTime();
           }
        }
        
    }
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_DOWN){
		cp.seta();
		cp.repaint();
		}
		}

	@Override
	public void keyReleased(KeyEvent e) {
		
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	class CavansPanel extends JPanel implements Runnable {
		 //锟斤拷锟斤拷锟斤拷锟斤拷
			int a=0;
			 int b=0;
			 int c1=0;
			 int c2=0;
			 int c3=0;
			 int c4=0;
			 int c5=0;
			 int c6=0;
			 
			 int c8=0;
			 int c9=0;
			 int d=0;
			 int e=0;
			 int f=0;
			 int t1=50;
			 int t2=200;
			 int t3=30;
			 int pr=0;
				
		    final long deltaTime = 5L;
		    final int x1=600,y1=70;
		     int x0 = 600;
			int y0 = 70;
		    final double g = 2;
		    final int r = 20;
		    final int r1 = 15;
		    double t = 0;
		    double length = 1;
		    double w = Math.sqrt(g / length);
		    double psai = 1.5;
		    double T;
		    int x;
		    int y;
		    int m=5;
		    int n=5;
		    double sita;
		    
		    
		    
		    diamonds d1;
		    diamonds d2;
		    gold g1;
		    gold g2;
		    gold g3;
		    gold g4;
		    stone s1;
		    stone s2;
		    mgold m1;
		    mgold m2;
		    yellow ye1;
		    
		    
		    
		    int dx1=300;
		    int dy1=300;
		    int dx2=650;
		    int dy2=200;
		    int gx1=390;
		    int gy1=250;
		    int gx2=100;
		    int gy2=630;
		    int gx3=220;
		    int gy3=408;
		    int gx4=700;
		    int gy4=400;
		    int sx1=200;
		    int sy1=770;
		    int sx2=1006;
		    int sy2=290;
		    int mx1=930;
		    int my1=650;
		    int mx2=1070;
		    int my2=440;
		    int rx1=200;
		    int ry1=300;
		    
		  
		    
		    
		    
		    
		    
		     //锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
		    public CavansPanel() {
		        this.setPreferredSize(new Dimension(400, 400));//锟斤拷锟斤拷锟斤拷玫拇锟叫�
		   
		    }
		    //
		    
		    
		    
		   
		   //锟斤拷锟斤拷1
		    public void init(double len, double deg) {
		    	
		        length = len;//锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟叫碉拷length为锟斤拷锟斤拷
		        psai = Math.toRadians(deg);
		        w = Math.sqrt(g / length);
		        T = 2 * Math.PI * Math.sqrt(length / g);
		    }
		    //锟斤拷锟斤拷1
		     
		    
		    
		    
		    
		    
		    //锟斤拷锟斤拷2
		public void run0(){
			sita = psai * Math.cos(w * t + psai);
		    x = (int) (x0 + length * 100 * Math.sin(sita));
		    y = (int) (y0 + length * 100 * Math.cos(sita));
		}
			//锟斤拷锟斤拷2






		//锟斤拷锟斤拷3
		public void stop(){
			int x ;
			int y ;
		 }
		//锟斤拷锟斤拷3






		//锟斤拷锟斤拷4
		public void left(){
			x=x-m;
			y=y+n;
			}
		//锟斤拷锟斤拷4



		

		//锟斤拷锟斤拷5
		public void right()
		    {
			
			x=x+m;
			y=y+n;
			
			}
		//锟斤拷锟斤拷5

		






		//锟斤拷锟斤拷6
		public void seta(){
			a=1;
		}
		//锟斤拷锟斤拷6







		//锟斤拷锟斤拷7
		public void moveRect(){
			t1+=x1;
			t2+=y1;
		}
		//锟斤拷锟斤拷7
		  
		
		






	//锟斤拷锟斤拷8
		    public void paintComponent(Graphics g) {
		        super.paintComponent(g);
		   //锟斤拷锟斤拷图片锟斤拷为锟斤拷锟斤拷
		       
		        
		      
		   //a=0锟斤拷始为锟斤拷锟斤拷锟剿讹拷
		   if(a==0)
		   {
		       run0();
		   }
		   
		  
		   //b=0时锟劫讹拷为锟斤拷锟斤拷锟斤拷锟斤拷
		   if(b==0){
			   m=1;
			   n=1;
			   
		   }
		   //b=1时锟斤拷锟斤拷锟斤拷锟斤拷
		   if(b==1){
			   m=-1;
	        	n=-1;
	        	
		   }
		   
		   //a=1时锟斤拷锟斤拷锟狡讹拷
		   if(a==1)
		   {
		       stop();
		       if(sita<0.1)
		          {
		    	   
		                left();
		          }
		        	
		       else
		            {
		    	   
		                right();
		        	}
		       
		        		     		
		   }
		   
		   
		   //锟斤拷锟斤拷锟斤拷锟斤拷锟皆碉拷锟斤拷锟斤拷锟斤拷栈锟�
		   if(x<0||x>1500||y>1200)
		         {
		        	b=1;
		     		 
		         }
		  
		   
		   //锟斤拷锟斤拷锟斤拷锟斤拷盏锟斤拷锟斤拷匣氐锟皆伙拷锟斤拷锟斤拷锟斤拷锟绞硷拷锟斤拷锟斤拷硕锟�
		   if(y<0){
			 a=0;
			 b=0;
		   }
		   repaint();
		        
		   //锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷樱锟斤拷锟斤拷栈锟�
		   if(x-dx1<50&&x>dx1&&y-dy1<40&&y>dy1){
			   b=1;
			  c1=1;
		
		   }
		   
		   if(x-gx1<150&&x>gx1&&y-gy1<120&&y>gy1){
			   b=1;
			  c3=1;
		
		   }
		   if(x-gx2<150&&x>gx2&&y-gy2<120&&y>gy2){
			   b=1;
			  c4=1;
		
		   }
		   if(x-gx3<150&&x>gx3&&y-gy3<120&&y>gy3){
			   b=1;
			  c5=1;
		
		   }
		   if(x-gx4<150&&x>gx4&&y-gy4<120&&y>gy4){
			   b=1;
			  c6=1;
		
		   }
		   
		   if(x-mx1<90&&x>mx1&&y-my1<70&&y>my1){
			   b=1;
			  c8=1;
		
		   }
		   if(x-mx2<90&&x>mx2&&y-my2<70&&y>my2){
			   b=1;
			  c9=1;
		
		   }
		   if(x-rx1<90&&x>rx1&&y-ry1<120&&y>ry1){
			   b=1;
			  e=1;
		
		   }
		   
		
		   if(c1==1){
			  
				int dx=1;
				int dy=1;
				
				dx1=dx1+dx;
				dy1=dy1-dy;
				if(dy1<5){
					pr+=new diamonds(1,1).price;
					dy1=100000000;
				}
				
			    
			   }
		   
		   if(c3==1){
				  
				int dx=1;
				int dy=1;
				
				gx1=gx1+dx;
				gy1=gy1-dy;
				if(gy1<5){
					pr+=new gold(1,1).price;
					gy1=100000000;
				}
			    
			   }
		   if(c4==1){
				  
				int dx=1;
				int dy=1;
				
				gx2=gx2+dx;
				gy2=gy2-dy;
				if(gy2<5){
					pr+=new gold(1,1).price;
					gy2=100000000;
				}
				
			    
			   }
		   if(c5==1){
				  
				int dx=1;
				int dy=1;
				
				gx3=gx3+dx;
				gy3=gy3-dy;
				if(gy3<5){
					pr+=new gold(1,1).price;
					gy3=100000000;
				}
				
			    
			   }
		   if(c6==1){
				  
				int dx=1;
				int dy=1;
				
				gx4=gx4-dx;
				gy4=gy4-dy;
				if(gy4<5){
					pr+=new gold(1,1).price;
					gy4=100000000;
				}
			    
			   }
		   
		   if(c8==1){
				  
				int dx=1;
				int dy=1;
				
				mx1=mx1-dx;
				my1=my1-dy;
				if(my1<5){
					pr+=new mgold(1,1).price;
					my1=100000000;
				}
				
			    
			   }
		   if(c9==1){
				  
				int dx=1;
				int dy=1;
				
				mx2=mx2-dx;
				my2=my2-dy;
				if(my2<5){
					pr+=new mgold(1,1).price;
					my2=100000000;
				}
				
			    
			   }
		   if(e==1){
				  
				int dx=1;
				int dy=1;
				
				rx1=rx1+dx;
				ry1=ry1-dy;
				f=1;
			    
			   }
	       
		  
		if(rx1<400){
			
			int dx=5;
			if(f==1){
				dx=0;
			}
		    rx1+=dx;
			
			if(rx1>398){
				d=1;
			}
			
			
			
		}
		   
		if(d==1){
			
			int dx=10;
			if(f==1){
				dx=0;
			}
			
			rx1-=dx;
			
			
			if(rx1<200){
				d=0;
			}
	   }
		repaint();
		
		   
		   //锟斤拷锟斤拷图锟斤拷
		   ye1=new yellow(535,18);
	        ye1.draw(g);
		        g.drawLine(x1, y1, x, y);
		     g.fillOval(x1-5, y1-5, 10, 10);
		        g.drawLine((x - r / 2)-2, (y - r / 2)+10, (x - r / 2)+22, (y - r / 2)+10);
		        g.drawLine((x - r / 2)-2, (y - r / 2)+10, (x - r / 2)-10, (y - r / 2)+20);
		        g.drawLine((x - r / 2)+22, (y - r / 2)+10,         (x - r / 2)+30, (y - r / 2)+20);
		        g.setColor(Color.YELLOW);
		        g.fillRect(0,93,1200,10);
		        g.setFont(new Font(null,Font.BOLD,30));
		        g.drawString("score:"+pr, 850, 50);
		        
		        d1=new diamonds(dx1,dy1);
		        d1.draw(g);
		        g1=new gold(gx1,gy1);
		        g1.draw(g);
		        g2=new gold (gx2,gy2);
		        g2.draw(g);
		        g3=new gold(gx3,gy3);
		        g3.draw(g);
		        g4=new gold(gx4,gy4);
		        g4.draw(g);
                m1=new mgold(mx1,my1);
                m1.draw(g);
                m2=new mgold(mx2,my2);
                m2.draw(g);
                
		       
		        
		        
		        
		       
		    }
		    //锟斤拷锟斤拷8
		 
		  
		   
		    
		    
		    
		    
		    //锟斤拷锟斤拷9
		    public void run() {
		        // TODO Auto-generated method stub
		        while(true)
		        {
		            t += deltaTime / 1000.0;
		            if(t >= T)
		                t -= T;
		            try 
		            		{
		                Thread.sleep(deltaTime);
		            		}
		            catch (InterruptedException e)
		            		{
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            		}
		            repaint();
		            
		         }
		        
		        			  }
			
		    //锟斤拷锟斤拷9
		    
		    
		    
		    
		    
		    
		     }
}
