import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
public class pann extends JFrame implements ActionListener {
 private JPasswordField passwordField;
 private JTextField textField;
 JPanel p1;
 
 
 
 
 
 public pann() {
  super("gold miner go");
  setUndecorated(true);//͸��
  
  //���ñ���
  String path = "gold.jpg";  
  ImageIcon background = new ImageIcon(path);  
  JLabel label1 = new JLabel(background);
  label1.setBounds(0, 0, 1200,900);  
  p1 = (JPanel) this.getContentPane();  
  p1.add(label1);
  p1.setLayout(null);
 p1.setOpaque(false);  
 this.getLayeredPane().add(label1, new Integer(Integer.MIN_VALUE));  
 
 
  this.setSize(1200,800);//���ÿ�ܵĴ�С
  this.setLocationRelativeTo(null);//ʹ������ʾ����Ļ����
  
  

  p1.setLayout(null);
  setBounds(100, 100, 299, 295);
  
  
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  
  //����
  final JLabel label = new JLabel();
  label.setText("name");
  label.setFont(new Font(null, Font.BOLD,50));
  label.setBounds(233, 110, 200, 100);
 
  p1.add(label);
  textField = new JTextField();
  
  
  textField.setBounds(507, 135, 300, 50);
  getContentPane().add(textField);
  final JLabel label_1 = new JLabel();
  
  //����
  label_1.setText("Passport");
  label_1.setFont(new Font(null, Font.BOLD,50));
  label_1.setBounds(233, 200, 400, 200);
 p1.add(label_1);
  passwordField = new JPasswordField();
  
  
  passwordField.setBounds(507, 270, 300, 50);
 p1.add(passwordField);
  final JButton btnLogin = new JButton();
  btnLogin.addActionListener(this);
  
  btnLogin.setBackground(Color.YELLOW);
  btnLogin.setOpaque(false);  
  btnLogin.setFont(new Font(null, Font.BOLD,50));
  btnLogin.setText("Log on");
 
  btnLogin.setBounds(150, 500, 400,120);
 p1.add(btnLogin);
  final JButton btnCancel = new JButton();
  
  btnCancel.setBackground(Color.YELLOW);
  btnCancel.setOpaque(false);  
  btnCancel.setFont(new Font(null, Font.BOLD,50));
  btnCancel.setText("Close");
  btnCancel.setBounds(650, 500, 400, 120);
 p1.add(btnCancel);
  this.setSize(1200,800);//���ÿ�ܵĴ�С
  this.setLocationRelativeTo(null);
  this.setVisible(true);
   
 }
 
 
 
 public void actionPerformed(final ActionEvent e) {
  if(e.getActionCommand().equals("Log on")){
   //���ݿ��ж�
	 new level4();
     this.dispose();
                                            }
  else if(e.getActionCommand().equals("Close")){
	  this.dispose();
                                               }
 }
 
 
 

 
 
 
}
 
 

 


