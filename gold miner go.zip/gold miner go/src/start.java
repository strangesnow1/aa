import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class start extends JFrame{
	
	JPanel p1;
	JButton button1;
	JButton button2;
	JButton button3;
	JButton button4;
	boolean a = true;
	boolean b = true;
	boolean c = true;
	int ss=0;
	
	
	public start(){
		super("Gold Miner Go");
		setUndecorated(true);
		 this.setSize(1200,800);
		this.setLocation(900,100);
		
		
		p1 = (JPanel) this.getContentPane();
		p1.setBounds(0,0,this.getWidth(), this.getHeight());
		   this.setLocationRelativeTo(null);//ʹ������ʾ����Ļ����
		
	
		button1 = new JButton();
		button2 = new JButton();
		button3 = new JButton();
		button4= new JButton();
		
		
		
		button4.setText("Close");
		button1.setBackground(Color.YELLOW);
		button2.setBackground(Color.YELLOW);
		button3.setBackground(Color.YELLOW);
		button4.setBackground(Color.YELLOW);
		 button1.setOpaque(false);  
		 button2.setOpaque(false);  
		 button3.setOpaque(false); 
		 button4.setOpaque(false); 
		
		
		button1.setBounds(440,660,320,150);
		button2.setBounds(920,700,80,80);
		button3.setBounds(200,700,80,80);
		button4.setBounds(980,50,200,50);
		
		button1.setFont(new Font("Aharoni", Font.BOLD, 30));
		button2.setFont(new Font("Aharoni", Font.BOLD, 25));
		button3.setFont(new Font("Aharoni", Font.BOLD, 30));
		button4.setFont(new Font("Aharoni", Font.BOLD, 30));
		
		button1.addActionListener(new B());
		button2.addActionListener(new B());
		button3.addActionListener(new B());
		button4.addActionListener(new B());
		
		
		
		
		String path = "ba.jpg";  
        ImageIcon background = new ImageIcon(path);  
        JLabel label = new JLabel(background); //label�����ݶ���Ϊpath 
        label.setBounds(-150,-350,1500,1500);  
        
        
        p1.setOpaque(false);  
        this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE)); 
	
		
		p1.setLayout(null);
		
		
		p1.add(button1);
		p1.add(button2);
		p1.add(button3);
		p1.add(button4);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	
	class B implements ActionListener{
		protected void dis (ActionEvent e){
			dispose();
		}
		
		Rules ds =new Rules();
		ranking r = new ranking();
		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource()==button1){
				new level4();
		dispose();
	
			}
		
			if (e.getSource()==button4){
				dis(e);
					
				}
			
			
			if (e.getSource()==button2){
				
				dispose();
				new ranking();
					}
		
			
			
			
		if(e.getSource()==button3){
			
			dispose();
			new Rules();
		}
		
	
			
		}
		}
		
	
		
	
public static void main(String agrs[]){
	new start();
	
	
}
}

