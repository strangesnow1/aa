
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;





public class details extends JFrame{
	JLabel labOne1;
	JPanel p1;
	JTextArea t;
	JButton b;
public details(){
		super("Details of rules");
		setUndecorated(true);
		this.setSize(1200,800);
		this.setLocation(900,100);
		 this.setLocationRelativeTo(null);//ʹ������ʾ����Ļ����
		String path = "m.jpg";  
        ImageIcon background = new ImageIcon(path);  
        JLabel label = new JLabel(background);
        label.setBounds(0, 0, this.getWidth(), this.getHeight());  
        
		   // �����ݴ���ת��ΪJPanel���������÷���setOpaque()��ʹ���ݴ���͸��  
	      p1 = (JPanel) this.getContentPane();  
	        p1.setLayout(null);
	        p1.setOpaque(false);  
	        
	        // �ѱ���ͼƬ���ӵ��ֲ㴰�����ײ���Ϊ����  
	        this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));  
		t=new JTextArea ("1.When you grasp different kind of mines, you will get different marks \n\n"  +
				"2.When players grasp thp the gold, the mark will increase\n\n" +
				"3.When you get enough marks, you can come to the next level\n");
		t.setSize(100,100);
		t.setLineWrap(true);
		t.setBounds(100,200,800,500);
		t.setFont(new Font("����", Font.BOLD, 45));
		t.setOpaque(false);  
		labOne1=new JLabel("Details of rules");
		labOne1.setBounds(200,100,1000,50);
		labOne1.setFont(new Font("����", Font.BOLD, 60));
		
	
		
		Container contentPane=this.getContentPane();
		
		b= new JButton("Close");
        b.setBounds(700,700,200,50);
        b.setFont(new Font("Aharoni", Font.BOLD, 30));
        b.setBackground(Color.YELLOW);
		b.setOpaque(false);  
		b.addActionListener(new B());
		

		p1.add(labOne1);
		p1.add(t);
		p1.add(b);
		

        
        
		
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		
	
	}


public static void main(String agrs[]){
	new details();
}
public class B implements ActionListener{
	
	public B(){
		
	}
protected void dis (ActionEvent e){
	dispose();
	new start();
}

	@Override
	public void actionPerformed(ActionEvent e) {
		dis(e);// TODO Auto-generated method stub
		
	}
	
}

	
}

