package level;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;

import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class sgold extends JFrame  {
	int x;
	int y;
Image image;
ImageIcon icon;
public int price=100;
	public sgold(int x, int y) {
	this.x=x;
	this.y=y;
	int price= 100;
		icon=new ImageIcon("sg.jpg");
		image=icon.getImage();
	
	}


	
	
	
public void draw(Graphics g) {
	g.drawImage(image,x,y,45,30,this);
}
}