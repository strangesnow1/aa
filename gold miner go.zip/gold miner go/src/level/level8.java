package level;

 
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
 
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
 
public class level8 extends JFrame implements KeyListener{
    CavansPanel cp = new CavansPanel();//����һ������
    
    ImageIcon im;//����һ��ͼƬ
    JLabel jl1;//������ǩ1
    JLabel jl2;//������ǩ2
    JLabel jl3;//������ǩ3
    long time = 30; // ����ʱ�����
    
   
    
    
    
    
     //������
    public level8() {
    	 super("level");//������ܣ��������
         setUndecorated(true);//���ÿ���ޱ߿�
         this.setSize(1200,800);//���ÿ�ܵĴ�С
 	    this.setLocationRelativeTo(null);//ʹ������ʾ����Ļ����
 	    
 	    String path = "c.jpg";  //·��
         ImageIcon background = new ImageIcon(path);//����ͼƬ  
         JLabel label = new JLabel(background);//ͼƬ���ӵ���ǩ��
         label.setBounds(0, 0,1300, 800);  
 	    
         this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));  
         
         JPanel i = (JPanel) this.getContentPane();  
         i.setLayout(null);
         i.setOpaque(false); 
         
         cp.setOpaque(false);
         
         this.addKeyListener(this);//���Ӽ�����
        
         this.setLayout(new BorderLayout());//���ÿ�ܲ���Ϊ�߿򲼾֣��߿򲼾ֶַ���������5����λ�����ӿؼ�
         i.add(cp, BorderLayout.CENTER);//������嵽��ܵ��м�λ��
         jl1 = new JLabel();//�����ǩ1
         jl2 = new JLabel();//�����ǩ2
         jl3 = new JLabel();//�����ǩ3
        
         cp.setLayout(null);
         jl2.setBounds(700, 10, 100, 100);
         jl3.setBounds(720, 10, 100, 100);
         JLabel ll =ll = new JLabel();//定义标签3
         ll.setBounds(1100, 30, 70, 50);
         ll.setFont(new Font(null, Font.BOLD,60));
         ll.setText("5");
         cp.add(ll);
         cp.add(jl1);
         cp.add(jl2);
         cp.add(jl3);
        
         
  
         
       
       
        
        
         this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//���ùرհ�ť
         this.setVisible(true);//����Ϊ�ɼ�
         new Thread(cp).start();//�����߳�

    }
     
    
    
    
    
    
    
    
    void getTime() {
       
        //����ʱ�������
       long hour=0;
        long minute = 0;
        long seconds = 0;
 
        while (time >= 0) {
            hour = time / 3600;//�õ�Сʱ
            minute = (time - hour * 3600) / 60;//�õ�����
            seconds = time - hour * 3600 - minute * 60;//�õ���
           
            jl2.setText(minute + ":");//�ڱ�ǩ�м����ʼ�ķ���
            jl3.setText(seconds+"");//�ڱ�ǩ�м����ʼ����
            
            jl2.setFont(new Font("Aharoni", Font.BOLD, 30));
            jl3.setFont(new Font("Aharoni", Font.BOLD, 30));
           
            //����ʱ����
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            time--;
            if(time<1){
              	 dispose();
              	 new level9().getTime();
              }
        }
 
    }
 
    
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_DOWN){
			cp.seta();
			cp.repaint();
			}
		}
//�������°�ťʱ�����������˶�
	
	
	
	
	@Override
	public void keyReleased(KeyEvent e) {
		
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	
	
	
	
	class CavansPanel extends JPanel implements Runnable {
		 //��������
			int a=0;
			 int b=0;
			 int cd1=0;
			 int cd2=0;
			 int cd3=0;
			 int cg1=0;
			 int cg2=0;
			 int cs1=0;
			 int cs2=0;
			 int cs3=0;
			 int cs4=0;
			 int cr1=0;
			int rf1=0;
			 int csg2=0;
			 int csg3=0;
			 int csg4=0;
			 int cm1=0;
			 int cm2=0;
			 int cb1=0;
			 int cb2=0;
			 int cb3=0;
			 int cb4=0;
			 int aa=0;
		    final long deltaTime = 5L;
		    final int x1=600,y1=70;
		     int x0 = 600;
			int y0 = 70;
		    final double g = 2;
		    final int r = 20;
		    final int r1 = 15;
		    double t = 0;
		    double length = 1;
		    double w = Math.sqrt(g / length);
		    double psai = 1.5;
		    double T;
		    int x;
		    int y;
		    int m=5;
		    int n=5;
		    double sita;
		   
		    
		    
		    
		    
		    
		    
		    
		    //��������
		    diamonds d1;
		    diamonds d2;
		    diamonds d3;
		   
		    
		    
		    gold g1;
		    gold g2;
		    
		    
		    yellow ye1;
		   
		    
		    
		    stone s1;
		    stone s2;
		    stone s3;
		    stone s4;
		    rabbit ra1;
		    
	
		    sgold sg2;
		    sgold sg3;
		    sgold sg4;
		    
		    
		    mgold m1;
		    mgold m2;
		   
		    
		    bag b1;
		    bag b2;
		    bag b3;
		    bag b4;
		    
		    
		    
		    
		    //��������
		    int dx1=500;
		    int dy1=300;
		    int dx2=700;
		    int dy2=200;
		    int dx3=392;
		    int dy3=302;
		   
		    
		    
		    int gx1=800;
		    int gy1=300;
		    int gx2=830;
		    int gy2=580;
		    
		    
		    
		    int rx1=120;
		    int ry1=444;
		 
		   
		 
		    
		    
		  
		    int sx2=400;
		    int sy2=600;
		    int sx3=100;
		    int sy3=900;
		    int sx4=300;
		    int sy4=700;
		    
		    
		    
		    int mx1=400;
		    int my1=400;
		    int mx2=400;
		    int my2=400;
		   
		    int rr1=0;
		    
		    
		    int sgx1=630;
		    int sgy1=332;
		    int sgx2=300;
		    int sgy2=320;
		    int sgx3=100;
		    int sgy3=442;
		    int sgx4=33;
		    int sgy4=320;
		   
		    
		    
		    
		    
		    int bx1=600;
		    int by1=600;
		    int bx2=40;
		    int by2=200;
		    int bx3=120;
		    int by3=600;
		    int bx4=20;
		    int by4=50;
		    
		   int pr=0;
		   
		    
		  
		    
		    
		    
		    
		    
		     //����������
		    public CavansPanel() {
		        this.setPreferredSize(new Dimension(400, 400));//������õĴ�С
		   
		    }
		    //
		    
		    
		    
		   
		   //����1
		    public void init(double len, double deg) {
		    	
		        length = len;//�������������е�lengthΪ����
		        psai = Math.toRadians(deg);
		        w = Math.sqrt(g / length);
		        T = 2 * Math.PI * Math.sqrt(length / g);
		    }
		    //���ӵĵ����˶�
		     
		    
		    
		    
		    
		    
		    //����2
		public void run0(){
			sita = psai * Math.cos(w * t + psai);
		    x = (int) (x0 + length * 100 * Math.sin(sita));
		    y = (int) (y0 + length * 100 * Math.cos(sita));
		}
			//���ӵĵ����˶�






		//����3
		public void stop(){
			int x ;
			int y ;
		 }
		//�������°�ťʱ������ֹͣ�˶�






		//����4
		public void left(){
			x=x-m;
			y=y+n;
			}
		//���������˶�



		

		//����5
		public void right()
		    {
			
			x=x+m;
			y=y+n;
			
			}
		//���������˶�

		






		//����6
		public void seta(){
			a=1;
		}
		//���Ʊ���








		
		






	//����7
		    public void paintComponent(Graphics g) {
		        super.paintComponent(g);
		   
		        
		        g.setFont(new Font(null, Font.BOLD, 30));
		       
		        //����ͼƬ��Ϊ����
		      
		   //a=0��ʼΪ�����˶�
		   
		         
		   if(a==0)
		   {
		       run0();
		   }
		 //a=1ʱ���������ƶ�
		   if(a==1)
		   {
			  
		       stop();
		       if(sita<0.1)
		          {
		    	   
		                left();
		          }
		        	
		       else
		            {
		    	   
		                right();
		        	}
		       
		        		     		
		   }
		  
		   //b=0ʱ�ٶ�Ϊ��������
		   if(b==0){
			   m=1;
			   n=1;
			   
		   }
		   //b=1ʱ��������
		   if(b==1){
			   m=-1;
	        	n=-1;
	        	
		   }
		   
		   
		   
		   
		   //���������Ե�������ջ�
		   if(x<0||x>1500||y>800)
		         {
		        	b=1;
		     		 
		         }
		  
		   
		   //��������յ����ϻص�ԭλ��������ʼ�����˶�
		   if(y<0){
			 a=0;
			 b=0;
			
		   }
		  
		   repaint();
		        
		   //��������������ӣ����ջأ��ҽ���һ������
		   if(x-dx1<50&&x>dx1&&y-dy1<40&&y>dy1){
			   b=1;
			  cd1=1;
			 
		    	
		
		   }
		   if(x-dx2<50&&x>dx2&&y-dy2<40&&y>dy2){
			   b=1;
			  cd2=1;
			 
		    	
		
		   }
		   if(x-dx3<50&&x>dx3&&y-dy3<40&&y>dy3){
			   b=1;
			  cd3=1;
			 
		    	
		
		   }
		   if(x-gx1<100&&x>gx1&&y-gy1<80&&y>gy1){
			   b=1;
			  cg1=1;
			
		    	
		
		   }
		   if(x-gx2<100&&x>gx2&&y-gy2<80&&y>gy2){
			   b=1;
			  cg2=1;
			
		    	
		
		   }
		   if(x-sx2<100&&x>sx2&&y-sy2<80&&y>sy2){
			   b=1;
			  cs2=1;
			
		    	
		
		   }
		   if(x-sx3<100&&x>sx3&&y-sy3<80&&y>sy3){
			   b=1;
			  cs3=1;
			
		    	
		
		   }
		   if(x-sx4<100&&x>sx4&&y-sy4<80&&y>sy4){
			   b=1;
			  cs4=1;
			
		    	
		
		   }
		   if(x-sgx2<45&&x>sgx2&&y-sgy2<30&&y>sgy2){
			   b=1;
			  csg2=1;
			
		    	
		
		   }
		   if(x-sgx3<45&&x>sgx3&&y-sgy3<30&&y>sgy3){
			   b=1;
			  csg3=1;
			
		    	
		
		   }
		   if(x-sgx4<45&&x>sgx4&&y-sgy4<30&&y>sgy4){
			   b=1;
			  csg4=1;
			
		    	
		
		   }
		   if(x-mx1<90&&x>mx1&&y-my1<70&&y>my1){
			   b=1;
			  cm1=1;
			 
		    	
		
		   }
		   if(x-mx2<90&&x>mx2&&y-mx2<70&&y>mx2){
			   b=1;
			  cm2=1;
			 
		    	
		
		   }
		   if(x-bx1<100&&x>bx1&&y-by1<80&&y>by1){
			   b=1;
			  cb1=1;
			 
		    	
		
		   }
		   if(x-bx2<100&&x>bx2&&y-by2<80&&y>by2){
			   b=1;
			  cb2=1;
			 
		    	
		
		   }
		   if(x-bx3<100&&x>bx3&&y-by3<80&&y>by3){
			   b=1;
			  cb3=1;
			 
		    	
		
		   }
		   if(x-bx4<100&&x>bx4&&by4<80&&y>by4){
			   b=1;
			  cb4=1;
			 
		    	
		
		   }
		   if(x-rx1<60&&x>rx1&&y-ry1<80&&y>ry1){
			   b=1;
			  cr1=1;
		
		   }
		   
		//c1,2,3��eΪ�������ʯһ������
		   if(cd2==1){
				  
				int dx=1;
				int dy=1;
				if(dy2<5){
					pr+=new diamonds(1,1).price;
					dy2=100000000;
				}
				dx2=dx2-dx;
				dy2=dy2-dy;
				
			    
			   } if(cd3==1){
					  
					int dx=1;
					int dy=1;
					if(dy3<5){
						pr+=new diamonds(1,1).price;
						dy3=100000000;
					}
					dx3=dx3+dx;
					dy3=dy3-dy;
					
				    
				   }
		   if(cg1==1){
				  
				int dx=1;
				int dy=1;
				if(gy1<5){
					pr+=new gold(1,1).price;
					gy1=100000000;
				}
				gx1=gx1-dx;
				gy1=gy1-dy;
				
			    
			   }
		   if(cg2==1){
				  
				int dx=1;
				int dy=1;
				if(gy2<5){
					pr+=new gold(1,1).price;
					gy2=100000000;
				}
				gx2=gx2+dx;
				gy2=gy2-dy;
				
			    
			   
		    }
			   
		   
		   if(cs2==1){
				  
				int dx=1;
				int dy=1;
				if(sy2<5){
					pr+=new stone(1,1).price;
					sy2=100000000;
				}
				sx2=sx2-dx;
				sy2=sy2-dy;
				
			    
			   }
		   if(cs3==1){
				  
				int dx=1;
				int dy=1;
				if(sy3<5){
					pr+=new stone(1,1).price;
					sy3=100000000;
				}
				sx3=sx3-dx;
				sy3=sy3-dy;
				
			    
			   }
		   if(cs4==1){
				  
				int dx=1;
				int dy=1;
				if(sy4<5){
					pr+=new stone(1,1).price;
					sy4=100000000;
				}
				sx4=sx4-dx;
				sy4=sy4-dy;
				
			    
			   }
		   
		   if(csg2==1){
				  
				int dx=1;
				int dy=1;
				if(sgy2<5){
					pr+=new sgold(1,1).price;
					sgy2=100000000;
				}
				sgx2=sgx2+dx;
				sgy2=sgy2-dy;
				
			    
			   }
		   if(csg3==1){
				  
				int dx=1;
				int dy=1;
				if(sgy3<5){
					pr+=new sgold(1,1).price;
					sgy3=100000000;
				}
				sgx3=sgx3=+dx;
				sgy3=sgy3-dy;
				
			    
			   }
		   if(csg4==1){
				  
				int dx=1;
				int dy=1;
				if(sgy4<5){
					pr+=new sgold(1,1).price;
					sgy4=100000000;
				}
				sgx4=sgx4+dx;
				sgy4=sgy4-dy;
				
			    
			   }
		   if(cm1==1){
				  
				int dx=1;
				int dy=1;
				if(my1<5){
					pr+=new mgold(1,1).price;
					my1=100000000;
				}
				mx1=mx1-dx;
				my1=my1-dy;
				
			    
			   }
		   if(cm2==1){
				  
				int dx=1;
				int dy=1;
				if(my2<5){
					pr+=new mgold(1,1).price;
					my2=100000000;
				}
				mx2=mx2-dx;
				my2=my2-dy;
				
			    
			   }
		   if(cb1==1){
				  
				int dx=1;
				int dy=1;
				if(by1<5){
					pr+=new bag(1,1).price;
					by1=100000000;
				}
				bx1=bx1-dx;
				by1=by1-dy;
				
			    
			   }
		   if(cb2==1){
				  
				int dx=1;
				int dy=1;
				if(by2<5){
					pr+=new bag(1,1).price;
					by2=100000000;
				}
				bx2=bx2-dx;
				by2=by2-dy;
				
			    
			   }
		  
		   if(cb4==1){
				  
				int dx=1;
				int dy=1;
				if(by4<5){
					pr+=new bag(1,1).price;
					by4=100000000;
				}
				bx4=bx4-dx;
				by4=by4-dy;
				
			    
			   }
		  
		   if(cb3==1){
				  
				int dx=1;
				int dy=1;
				if(by3<5){
					pr+=new bag(1,1).price;
					by3=100000000;
				}
				bx3=bx3-dx;
				by3=by3-dy;
				
			    
			   }
		  
		  
		   if(cr1==1){
				  
				int dx=1;
				int dy=1;
				if(by2<5){
					pr+=new bag(1,1).price;
					by2=100000000;
				}
				rx1=rx1+dx;
				ry1=ry1-dy;
				rf1=1;
			    
			   }
	       
		  
		   
		   
		   if(rx1<300){
				
				int dx=1;
				if(rf1==1){
					dx=0;
				}
			    rx1+=dx;
			    if(rf1==1){
					dx=0;
				}
				if(rx1>299){
					rr1=1;
				}
				
				
				
				
			}
			   
		   
		   if(rr1==1){
				
			   int dx=2;
				if(rf1==1){
					dx=0;
				}
				rx1-=dx;
				
				if(rx1<130){
					rr1=0;
				}
		   }
		   
		   
		   //���ӵ������˶�
		
		   
		   
		   
		
		
		
		
		
		   //����ͼ��
		   ye1=new yellow(535,18);
	        ye1.draw(g);
		        g.drawLine(x1, y1, x, y);
		     g.fillOval(x1-5, y1-5, 10, 10);
		    
		        g.drawLine((x - r / 2)-2, (y - r / 2)+10, (x - r / 2)+22, (y - r / 2)+10);
		        g.drawLine((x - r / 2)-2, (y - r / 2)+10, (x - r / 2)-10, (y - r / 2)+20);
		        g.drawLine((x - r / 2)+22, (y - r / 2)+10,         (x - r / 2)+30, (y - r / 2)+20);
		        g.setColor(Color.YELLOW);
		        
		        if(aa==1){
		        	pr=500;
		        }
		        g.drawString("count: "+pr,850,50);
		       	        
		        
		        
		        

		        d1=new diamonds(dx1,dy1);
		        d1.draw(g);
		        d2=new diamonds(dx2,dy2);
		        d2.draw(g);
		        d3=new diamonds(dx3,dy3);
		        d3.draw(g);
		       
		        
		        
		        g1=new gold(gx1,gy1);
		        g1.draw(g);
		        g2=new gold(gx2,gy2);
		        g2.draw(g);
		        
		        ra1=new rabbit(rx1,ry1);
		        ra1.draw(g);
		        
		        
		        
		       
		    
		      s2=new stone(sx2,sy2);
		      s2.draw(g);
		      s3=new stone(sx3,sy3);
		      s3.draw(g);
		      s4=new stone(sx3,sy3);
		      s4.draw(g);
		      
		      
		      
		    
		      sg2=new sgold(sgx2,sgy2);
		      sg2.draw(g);
		      sg3=new sgold(sgx3,sgy3);
		      sg3.draw(g);
		      sg4=new sgold(sgx4,sgy4);
		      sg4.draw(g);
		     
		      
		      
		      m1=new mgold(mx1,my1);
		      m1.draw(g);
		      m2=new mgold(mx2,my2);
		      m2.draw(g);
		      
		      
		      
		      b1=new bag(bx1,by1);
		      b1.draw(g);
		      b2=new bag(bx2,by2);
		      b2.draw(g);
		      b3=new bag(bx3,by3);
		      b3.draw(g);
		     
		      g.fillRect(0,93,1200,10);
		        
		      
		        
		       
		    }
		    //����8
		 
		  
		   
		    
		    
		    
		    
		    //����9
		    public void run() {
		        // TODO Auto-generated method stub
		        while(true)
		        {
		            t += deltaTime / 1000.0;
		            if(t >= T)
		                t -= T;
		            try 
		            		{
		                Thread.sleep(deltaTime);
		            		}
		            catch (InterruptedException e)
		            		{
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            		}
		            repaint();
		            
		         }
		        
		        			  }
			
		    //����9
		    
		    
	}
		    
		   
		    
	
}
