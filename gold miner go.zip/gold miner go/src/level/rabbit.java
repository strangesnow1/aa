package level;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;

import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class rabbit extends JFrame  {
	int x;
	int y;
	int price=610;
Image image;
ImageIcon icon;
	public rabbit(int x, int y) {
	this.x=x;
	this.y=y;
	
	icon=new ImageIcon("ra.jpg");
		image=icon.getImage();
	
	}


	
	
	
public void draw(Graphics g) {
	g.drawImage(image,x,y,60,80,this);
	
}






   
   
	
	
}
