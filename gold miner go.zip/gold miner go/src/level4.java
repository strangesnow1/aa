
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
 
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
 
public class level4 extends JFrame implements KeyListener{
     //�������ֶ���
    CavansPanel cp = new CavansPanel();//����һ����ǩ���
    JPanel ctrl = new JPanel();//����һ�����
    ImageIcon im;
   JLabel jl1;
   JLabel jl2;
   JLabel jl3;
   JLabel ll;
   long time = 30; // ����ʱ�����
     //����������
    public level4() {
    	super("level");//������ܣ��������
        setUndecorated(true);//���ÿ���ޱ߿�
        this.setSize(1200,800);//���ÿ�ܵĴ�С
	    this.setLocationRelativeTo(null);//ʹ������ʾ����Ļ����
	    
	    String path = "c.jpg";  //·��
        ImageIcon background = new ImageIcon(path);//����ͼƬ  
        JLabel label = new JLabel(background);//ͼƬ���ӵ���ǩ��
        label.setBounds(0, 0,1300, 800);  
	    
        this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));  
        
        JPanel i = (JPanel) this.getContentPane();  
        i.setLayout(null);
        i.setOpaque(false); 
        
        cp.setOpaque(false);
        
        this.addKeyListener(this);//���Ӽ�����
        ctrl.setLayout(new GridLayout(2, 3, 0, 10));//�������Ĳ���
        this.setLayout(new BorderLayout());//���ÿ�ܲ���Ϊ�߿򲼾֣��߿򲼾ֶַ���������5����λ�����ӿؼ�
        i.add(cp, BorderLayout.CENTER);//������嵽��ܵ��м�λ��
        jl1 = new JLabel();//�����ǩ1
        jl2 = new JLabel();//�����ǩ2
        jl3 = new JLabel();//�����ǩ3
       
      
        cp.setLayout(null);
        jl2.setBounds(700, 10, 100, 100);
        jl3.setBounds(720, 10, 100, 100);
        
        JLabel ll =ll = new JLabel();//定义标签3
        ll.setBounds(1100, 30, 70, 50);
        ll.setFont(new Font(null, Font.BOLD,60));
        ll.setText("1");
        cp.add(ll);
        cp.add(jl2);
        cp.add(jl3);
      
        
 
        
      
      
       
       
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//���ùرհ�ť
        this.setVisible(true);//����Ϊ�ɼ�
        new Thread(cp).start();//�����߳�
        
        
    }
     
    
    
   
     void getTime() {
        
        //����ʱ�������
       long hour=0;
        long minute = 0;
        long seconds = 0;
       
       
        while (time >= 0) {
            hour = time / 3600;//�õ�Сʱ
            minute = (time - hour * 3600) / 60;//�õ�����
            seconds = time - hour * 3600 - minute * 60;//�õ���
           
            jl2.setText(minute + ":");//�ڱ�ǩ�м����ʼ�ķ���
            jl3.setText(seconds+"");//�ڱ�ǩ�м����ʼ����
            
            jl2.setFont(new Font("Aharoni", Font.BOLD, 30));
            jl3.setFont(new Font("Aharoni", Font.BOLD, 30));
           
            //����ʱ����
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            time--;
           
        }
        
    }

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_DOWN){
		cp.seta();
		cp.repaint();
		}
		}

	@Override
	public void keyReleased(KeyEvent e) {
		
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	class CavansPanel extends JPanel implements Runnable {
		 //��������
			int a=0;
			 int b=0;
			 int c1=0;
			 int c2=0;
			 int c3=0;
			 int c4=0;
			 int c5=0;
			 int c6=0;
			 int d1=0;
			 int d2=0;
			 int d3=0;
			 
			 int cb1=0;
			 
			 int d=0;
			 int e=0;
			 int f=0;
			 int h=0;
			 int t1=50;
			 int t2=200;
			 int t3=30;
			
				
			 
			 
			 
		    final long deltaTime = 5L;
		    final int x1=600,y1=70;
		     int x0 = 600;
			int y0 = 70;
		    final double g = 2;
		    final int r = 20;
		    final int r1 = 15;
		    double t = 0;
		    double length = 1;
		    double w = Math.sqrt(g / length);
		    double psai = 1.5;
		    double T;
		    int x;
		    int y;
		    int pr=0;
		    
		    double sita;
		    
		    
		    
		    stone s1;
		    stone s2;
		    stone s3;
		    
		    
		    
		    gold g1;
		    gold g2;
		    
		    
		    sgold sg1;
		    sgold sg2;
		    sgold sg3;
		    sgold sg4;
		    
		    
		    yellow ye1;
		    
		    
		    rabbit ra1;
		    
		    
		    bag b1;
		    
		    int sx1=300;
		    int sy1=550;
		    int sx2=780;
		    int sy2=400;
		    int sx3=550;
		    int sy3=340;
		    
		    
		    
		    int gx1=100;
		    int gy1=600;
		    int gx2=200;
		    int gy2=400;
		    
		    
		    int sgx1=950;
		    int sgy1=450;
		    int sgx2=600;
		    int sgy2=800;
		    int sgx3=520;
		    int sgy3=700;
		    int sgx4=600;
		    int sgy4=511;
		    int rx1=200;
		    int ry1=300;
		    int bx1=800;
		    int by1=550;
		    int ye1x=500;
		    int yely=500;
		    int m=60;
		    int n=60;
		   
		    
		    
		  
		    
		    
		    
		     //����������
		    public CavansPanel() {
		        this.setPreferredSize(new Dimension(400, 400));//������õĴ�С
		   
		    }
		    //
		    
		    
		    
		   
		   //����1
		    public void init(double len, double deg) {
		    	
		        length = len;//�������������е�lengthΪ����
		        psai = Math.toRadians(deg);
		        w = Math.sqrt(g / length);
		        T = 2 * Math.PI * Math.sqrt(length / g);
		    }
		    //����1
		     
		    
		    
		   
		    
		    
		    //����2
		public void run0(){
			sita = psai * Math.cos(w * t + psai);
		    x = (int) (x0 + length * 100 * Math.sin(sita));
		    y = (int) (y0 + length * 100 * Math.cos(sita));
		}
			//����2






		//����3
		public void stop(){
			int x ;
			int y ;
		 }
		//����3






		//����4
		public void left(){
			 
			    
			x=x-m;
			y=y+n;
			}
		//����4



		

		//����5
		public void right()
		    {
			
			    
			
			x=x+m;
			y=y+n;
			
			}
		//����5

		






		//����6
		public void seta(){
			a=1;
		}
		//����6







		//����7
		public void moveRect(){
			t1+=x1;
			t2+=y1;
		}
		//����7
		  
		
		






	//����8
		    public void paintComponent(Graphics g) {
		        super.paintComponent(g);
		   //����ͼƬ��Ϊ����
		       
		        
		      
		   //a=0��ʼΪ�����˶�
		   if(a==0)
		   {
		       run0();
		   }
		   
		  
		   //b=0ʱ�ٶ�Ϊ��������
		   if(b==0){
			   m=1;
			   n=1;
			   
		   }
		   //b=1ʱ��������
		   if(b==1){
			   m=-1;
	        	n=-1;
	        	
		   }
		   
		   //a=1ʱ�����ƶ�
		   if(a==1)
		   {
		       stop();
		       if(sita<0.1)
		          {
		    	   
		                left();
		          }
		        	
		       else
		            {
		    	   
		                right();
		        	}
		       
		        		     		
		   }
		   
		   
		   //���������Ե�������ջ�
		   if(x<0||x>1000||y>800)
		         {
		        	b=1;
		     		 
		         }
		  
		   
		   //��������յ����ϻص�ԭλ��������ʼ�����˶�
		   if(y<0){
			 a=0;
			 b=0;
		   }
		   repaint();
		        
		   if(x-gx1<150&&x>gx1&&y-gy1<120&&y>gy1){
			   b=1;
			  c1=1;
		
		   }
		   if(x-gx2<150&&x>gx2&&y-gy2<120&&y>gy2){
			   b=1;
			  c2=1;
		
		   }
		   
		   
		   
		   
		   if(x-sgx1<45&&x>sgx1&&y-sgy1<30&&y>sgy1){
			   b=1;
			  c3=1;
		
		   }
		   if(x-sgx2<45&&x>sgx2&&y-sgy2<30&&y>sgy2){
			   b=1;
			  c4=1;
		
		   }
		   if(x-sgx3<45&&x>sgx3&&y-sgy3<30&&y>sgy3){
			   b=1;
			  c5=1;
		
		   }
		   if(x-sgx4<45&&x>sgx4&&y-sgy4<30&&y>sgy4){
			   b=1;
			  c6=1;
		
		   }
		   if(x-rx1<60&&x>rx1&&y-ry1<80&&y>ry1){
			   b=1;
			  e=1;
		
		   }
		   if(x-sx1<100&&x>sx1&&y-sy1<80&&y>sy1){
			   b=1;
			  d1=1;
		
		   }
		   if(x-sx2<100&&x>sx2&&y-sy2<80&&y>sy2){
			   b=1;
			  d2=1;
		
		   }
		   if(x-sx3<100&&x>sx3&&y-sy3<80&&y>sy3){
			   b=1;
			  d3=1;
		
		   }
		   
		   if(x-bx1<100&&x>bx1&&y-by1<80&&y>by1){
			   b=1;
			  cb1=1;
		
		   }
		   
		
		   if(c1==1){
			  
				int dx=1;
				int dy=1;
				
				gx1=gx1+dx;
				gy1=gy1-dy;
				if(gy1<5){
					pr+=new gold(1,1).price;
					gy1=100000000;
				}
			    
			   }
		  
		   if(c2==1){
				  
				int dx=1;
				int dy=1;
				
				gx2=gx2+dx;
				gy2=gy2-dy;
				if(gy2<5){
					pr+=new gold(1,1).price;
					gy2=100000000;
				}
				
			    
			   }
		   if(c3==1){//rightmost
				  
				int dx=1;
				int dy=1;
				
				sgx1=sgx1-dx;
				sgy1=sgy1-dy;
				if(sgy1<5){
					pr+=new sgold(1,1).price;
					sgy1=100000000;
				}
			    
			   }
		   if(c4==1){
				  
				int dx=1;
				int dy=1;
				
				sgx2=sgx2-dx;
				sgy2=sgy2-dy;
				if(sgy2<5){
					pr+=new sgold(1,1).price;
					sgy2=100000000;
				}
			    
			   }
		   if(c5==1){
				  
				int dx=1;
				int dy=1;
				
				sgx3=sgx3+dx;
				sgy3=sgy3-dy;
				if(sgy3<5){
					pr+=new sgold(1,1).price;
					sgy3=100000000;
				}
			    
			   } 
		   if(c6==1){
					  
					int dx=1;
					int dy=1;
					
					sgx4=sgx4+dx;
					sgy4=sgx4-dy;
					if(sgy4<5){
						pr+=new sgold(1,1).price;
						sgy4=100000000;
					}
				    
				   }
		   if(e==1){
				  
				int dx=1;
				int dy=1;
				
				rx1=rx1+dx;
				ry1=ry1-dy;
				f=1;
				if(ry1<5){
					pr+=new rabbit(1,1).price;
					ry1=100000000;
				}
			    
			   }
		   if(d1==1){
				  
				int dx=1;
				int dy=1;
				
				sx1=sx1-dx;
				sy1=sy1-dy;
				if(sy1<5){
					pr+=new stone(1,1).price;
					sy1=100000000;
				}
			    
			   }
		   if(d2==1){
				  
				int dx=1;
				int dy=1;
				
				sx2=sx2-dx;
				sy2=sy2-dy;
				if(sy2<5){
					pr+=new stone(1,1).price;
					sy2=100000000;
				}
			    
			   }
		   if(d3==1){
				  
				int dx=1;
				int dy=1;
				
				sx3=sx3-dx;
				sy3=sy3-dy;
				if(sy3<5){
					pr+=new stone(1,1).price;
					sy3=100000000;
				}
			    
			   }
		   if(h==1){
				  
				int dx=1;
				int dy=1;
				
				bx1=bx1-dx;
				by1=by1-dy;
				if(by1<5){
				pr+=300;
					by1=100000000;
				}
			    
			   }
	       
		  
		if(rx1<400){
			
			int dx=1;
			if(f==1){
				dx=0;
			}
		    rx1+=dx;
			
			if(rx1>398){
				d=1;
			}
			
			
			
		}
		   
		if(d==1){
			
			int dx=2;
			if(f==1){
				dx=0;
			}
			
			rx1-=dx;
			
			
			if(rx1<200){
				d=0;
			}
	   }
		repaint();
		
		   
		   //����ͼ��
		   ye1=new yellow(535,18);
	        ye1.draw(g);
		        g.drawLine(x1, y1, x, y);
		     g.fillOval(x1-5, y1-5, 10, 10);
		        g.drawLine((x - r / 2)-2, (y - r / 2)+10, (x - r / 2)+22, (y - r / 2)+10);
		        g.drawLine((x - r / 2)-2, (y - r / 2)+10, (x - r / 2)-10, (y - r / 2)+20);
		        g.drawLine((x - r / 2)+22, (y - r / 2)+10,         (x - r / 2)+30, (y - r / 2)+20);
		        g.setColor(Color.YELLOW);
		        g.setFont(new Font(null,Font.BOLD,30));
		        g.drawString("score:"+pr, 850, 50);
		        
		        g.fillRect(0,93,1200,10);
		        g1=new gold(gx1,gy1);
		        g1.draw(g);
		        g2=new gold(gx2,gy2);
		        g2.draw(g);
		        sg1=new sgold(sgx1,sgy1);
		        sg1.draw(g);
		        sg2=new sgold(sgx2,sgy2);
		        sg2.draw(g);
		        sg3=new sgold(sgx3,sgy3);
		        sg3.draw(g);
		        sg4=new sgold(sgx4,sgy4);
		        sg4.draw(g);
		        s1=new stone(sx1,sy1);
		        s1.draw(g);
		        s2=new stone(sx2,sy2);
		        s2.draw(g);
		        s3=new stone(sx3,sy3);
		        s3.draw(g);
		        
		        b1=new bag(bx1,by1);
		        b1.draw(g);
		        ra1=new rabbit(rx1,ry1);
		        ra1.draw(g);
		      
		        
		        
		        
		        
		       
		    }
		    //����8
		 
		  
		   
		    
		    
		    
		    
		    //����9
		    public void run() {
		        // TODO Auto-generated method stub
		        while(true)
		        {
		            t += deltaTime / 900.0;
		            if(t >= T)
		                t -= T;
		            try 
		            		{
		                Thread.sleep(deltaTime);
		            		}
		            catch (InterruptedException e)
		            		{
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            		}
		            repaint();
		            
		         }
		        
		        			  }
			
		    //����9
		    
		    
		    
		    
		    
		    
		     }
}



